﻿using System;
using System.Text;
using System.Windows.Forms;

namespace ULMSWinFormsApp.Forms
{
    public partial class FrmReports : Form
    {
        public FrmReports()
        {
            InitializeComponent();
        }

        private void btnGenerateReport_Click(object sender, EventArgs e)
        {
            /*
             * I added proper validation to ensure the user selects a report type.
             * Previously, the system would continue even if no selection was made.
             */
            string reportType = cmbReportType.Text.Trim();
            string studentId = txtReportStudentId.Text.Trim();

            if (string.IsNullOrWhiteSpace(reportType))
            {
                MessageBox.Show("Please select a report type.");
                return;
            }

            /*
             * FIX 1: Removed Thread.Sleep(4000)
             * This was causing the system to freeze and simulate poor performance.
             * It is not realistic in a production system.
             */

            StringBuilder report = new StringBuilder();

            report.AppendLine("===== ULMS REPORT =====");
            report.AppendLine("Report Type: " + reportType);
            report.AppendLine("Student ID Filter: " + studentId);
            report.AppendLine("Generated On: " + DateTime.Now);
            report.AppendLine();

            /*
             * FIX 2: Improved logic structure for better readability and reliability.
             */
            switch (reportType)
            {
                case "Student Summary Report":
                    report.AppendLine("Student Name: John Doe");
                    report.AppendLine("Programme: Software Engineering");
                    report.AppendLine("Status: Active");
                    break;

                case "Marks Report":
                    report.AppendLine("Subject 1: 78");
                    report.AppendLine("Subject 2: 65");
                    report.AppendLine("Subject 3: 80");

                    /*
                     * FIX 3: Corrected average calculation (previously incorrect 169 value)
                     */
                    double avg = (78 + 65 + 80) / 3.0;
                    report.AppendLine("Average: " + avg.ToString("0.00"));
                    break;

                case "Enrollment Report":
                    report.AppendLine("Course 1: Programming 1");
                    report.AppendLine("Course 2: Database Systems");
                    report.AppendLine("Semester: Semester 1");
                    break;

                default:
                    report.AppendLine("No valid report type selected.");
                    break;
            }

            /*
             * FIX 4: Ensures smooth output rendering without freezing
             */
            txtReportOutput.Text = report.ToString();
        }

        /*
         * Clear button resets report inputs
         */
        private void btnClearReport_Click(object sender, EventArgs e)
        {
            cmbReportType.SelectedIndex = -1;
            txtReportStudentId.Clear();
            txtReportOutput.Clear();
            txtReportStudentId.Focus();
        }

        /*
         * Back button closes the form
         */
        private void btnBackReport_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmReports_Load(object sender, EventArgs e)
        {
            // No changes required
        }
    }
}