﻿using System;
using System.Windows.Forms;
using ULMSWinFormsApp.Models;

namespace ULMSWinFormsApp.Forms
{
    public partial class FrmMarksCapture : Form
    {
        public FrmMarksCapture()
        {
            InitializeComponent();
        }

        private void btnCalculateResults_Click(object sender, EventArgs e)
        {
            /*
             * I added proper input validation to prevent system crashes
             * when users leave fields empty or enter invalid values.
             */
            if (string.IsNullOrWhiteSpace(txtMarkStudentId.Text) ||
                string.IsNullOrWhiteSpace(txtMarkStudentName.Text) ||
                string.IsNullOrWhiteSpace(txtSubject1.Text) ||
                string.IsNullOrWhiteSpace(txtSubject2.Text) ||
                string.IsNullOrWhiteSpace(txtSubject3.Text))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            MarkRecord record = new MarkRecord();

            record.StudentId = txtMarkStudentId.Text.Trim();
            record.StudentName = txtMarkStudentName.Text.Trim();

            /*
             * FIX 1: I replaced Convert.ToDouble with TryParse
             * This prevents system crashes when invalid text is entered.
             */
            double s1, s2, s3;

            if (!double.TryParse(txtSubject1.Text, out s1) ||
                !double.TryParse(txtSubject2.Text, out s2) ||
                !double.TryParse(txtSubject3.Text, out s3))
            {
                MessageBox.Show("Please enter numeric values only for marks.");
                return;
            }

            record.Subject1 = s1;
            record.Subject2 = s2;
            record.Subject3 = s3;

            /*
             * FIX 2: Corrected average calculation logic
             * Ensures all subjects are included properly
             */
            record.Average = (record.Subject1 + record.Subject2 + record.Subject3) / 3;

            /*
             * FIX 3: Result classification logic
             */
            if (record.Average >= 50)
            {
                record.ResultStatus = "PASS";
            }
            else
            {
                record.ResultStatus = "FAIL";
            }

            /*
             * FIX 4: Clean output formatting (IMPORTANT FIX)
             * I formatted the average to 2 decimal places to prevent long numbers like 46.6666667
             */
            txtMarksOutput.Text =
                "Marks processed successfully!" + Environment.NewLine +
                "Student ID: " + record.StudentId + Environment.NewLine +
                "Student Name: " + record.StudentName + Environment.NewLine +
                "Subject 1: " + record.Subject1 + Environment.NewLine +
                "Subject 2: " + record.Subject2 + Environment.NewLine +
                "Subject 3: " + record.Subject3 + Environment.NewLine +
                "Average: " + record.Average.ToString("0.00") + Environment.NewLine +
                "Final Result: " + record.ResultStatus;
        }

        /*
         * Clear button resets all input fields
         */
        private void btnClearMarks_Click(object sender, EventArgs e)
        {
            txtMarkStudentId.Clear();
            txtMarkStudentName.Clear();
            txtSubject1.Clear();
            txtSubject2.Clear();
            txtSubject3.Clear();
            txtMarksOutput.Clear();
            txtMarkStudentId.Focus();
        }

        /*
         * Back button closes the form
         */
        private void btnBackMarks_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmMarksCapture_Load(object sender, EventArgs e)
        {
            // No changes required here
        }
    }
}