using ULMSWinFormsApp.Forms;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace ULMSWinFormsApp
{
    public partial class FrmLogin : Form
    {
        /*
         * I have added a simulated user database using a Dictionary.
         * This was NOT in the original code.
         * It allows multiple users to log in instead of only one hardcoded user.
         */
        private Dictionary<string, string> users = new Dictionary<string, string>()
        {
            { "admin", "1234" },
            { "Aneesah", "1111" },
            { "Student01", "123456" }
        };

        public FrmLogin()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();

            /*
             * FIX 1: Added validation for empty input fields.
             * In the original system, blank inputs were treated as invalid credentials.
             * Now the system clearly prompts the user to fill in all fields.
             */
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            /*
             * FIX 2: Added username validation.
             * The system now checks if the username exists in the user list.
             * Previously, all errors were grouped into one message (invalid credentials).
             */
            if (!users.ContainsKey(username))
            {
                MessageBox.Show("Username incorrect.");
                return;
            }

            /*
             * FIX 3: Added password validation separately.
             * This ensures that even if the username is correct,
             * the password must also match the stored value.
             */
            if (users[username] != password)
            {
                MessageBox.Show("Password incorrect.");
                return;
            }

            /*
             * FIX 4: Successful login logic.
             * Only runs if BOTH username and password are correct.
             */
            MessageBox.Show("Login Successful!");

            FrmDashboard dashboard = new FrmDashboard();
            dashboard.Show();
            this.Hide();
        }

        /*
         * This method clears the input fields.
         * No changes were required here.
         */
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtUsername.Clear();
            txtPassword.Clear();
            txtUsername.Focus();
        }

        private void FrmLogin_Load(object sender, EventArgs e)
        {
            // No changes made to form load event
        }
    }
}