﻿using System;
using System.Windows.Forms;
using ULMSWinFormsApp.Models;

namespace ULMSWinFormsApp.Forms
{
    public partial class FrmCourseEnrollment : Form
    {
        /*
         * I added a simple in-memory list to track enrollments.
         * This was not included in the original system.
         * It is used to prevent duplicate course enrollments.
         */
        private static List<string> enrolledCourses = new List<string>();

        public FrmCourseEnrollment()
        {
            InitializeComponent();
        }

        private void btnEnroll_Click(object sender, EventArgs e)
        {
            /*
             * FIX 1: I added input validation to ensure all fields are filled.
             * Previously, the system allowed empty enrollments.
             */
            if (string.IsNullOrWhiteSpace(txtEnrollStudentId.Text) ||
                string.IsNullOrWhiteSpace(txtEnrollStudentName.Text) ||
                cmbCourse.SelectedIndex == -1 ||
                cmbSemester.SelectedIndex == -1)
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            string studentId = txtEnrollStudentId.Text.Trim();
            string studentName = txtEnrollStudentName.Text.Trim();
            string course = cmbCourse.Text;
            string semester = cmbSemester.Text;

            /*
             * FIX 2: I added duplicate enrollment prevention logic.
             * The system now checks if the student is already enrolled in the same course.
             */
            string enrollmentKey = studentId + "-" + course;

            if (enrolledCourses.Contains(enrollmentKey))
            {
                MessageBox.Show("Student already enrolled in this course.");
                return;
            }

            /*
             * FIX 3: If not duplicate, add enrollment to list
             */
            enrolledCourses.Add(enrollmentKey);

            Enrollment enrollment = new Enrollment
            {
                StudentId = studentId,
                StudentName = studentName,
                CourseName = course,
                Semester = semester
            };

            /*
             * FIX 4: Improved output formatting for clarity
             */
            txtEnrollmentOutput.Text =
                "Enrollment completed successfully!" + Environment.NewLine +
                "Student ID: " + enrollment.StudentId + Environment.NewLine +
                "Student Name: " + enrollment.StudentName + Environment.NewLine +
                "Course: " + enrollment.CourseName + Environment.NewLine +
                "Semester: " + enrollment.Semester;
        }

        /*
         * Clear button resets all input fields
         */
        private void btnClearEnrollment_Click(object sender, EventArgs e)
        {
            txtEnrollStudentId.Clear();
            txtEnrollStudentName.Clear();
            cmbCourse.SelectedIndex = -1;
            cmbSemester.SelectedIndex = -1;
            txtEnrollmentOutput.Clear();
            txtEnrollStudentId.Focus();
        }

        /*
         * Back button closes the form
         */
        private void btnBackEnrollment_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmCourseEnrollment_Load(object sender, EventArgs e)
        {
            // No changes required here
        }
    }
}